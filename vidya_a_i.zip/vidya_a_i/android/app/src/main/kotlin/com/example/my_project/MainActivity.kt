package com.mycompany.vidyaai

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
