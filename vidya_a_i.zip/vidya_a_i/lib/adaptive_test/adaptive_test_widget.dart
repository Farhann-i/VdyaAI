import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'adaptive_test_model.dart';
export 'adaptive_test_model.dart';

class AdaptiveTestWidget extends StatefulWidget {
  const AdaptiveTestWidget({super.key});

  @override
  State<AdaptiveTestWidget> createState() => _AdaptiveTestWidgetState();
}

class _AdaptiveTestWidgetState extends State<AdaptiveTestWidget> {
  late AdaptiveTestModel _model;

  final scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => AdaptiveTestModel());

    _model.switchValue1 = true;
    _model.switchValue2 = true;
    _model.switchValue3 = true;
    _model.switchValue4 = true;
    _model.switchValue5 = true;
    _model.switchValue6 = true;
    _model.switchValue7 = true;
    _model.switchValue8 = true;
    _model.switchValue9 = true;
    _model.switchValue10 = true;
    _model.switchValue11 = true;
    _model.switchValue12 = true;
    _model.switchValue13 = true;
    _model.switchValue14 = true;
    _model.switchValue15 = true;
    _model.switchValue16 = true;
    _model.switchValue17 = true;
    _model.switchValue18 = true;
    _model.switchValue19 = true;
    _model.switchValue20 = true;
    _model.switchValue21 = true;
    _model.switchValue22 = true;
    _model.switchValue23 = true;
    _model.switchValue24 = true;
    _model.switchValue25 = true;
    _model.switchValue26 = true;
    _model.switchValue27 = true;
    _model.switchValue28 = true;
    _model.switchValue29 = true;
    _model.switchValue30 = true;
    _model.switchValue31 = true;
    _model.switchValue32 = true;
    _model.switchValue33 = true;
    _model.switchValue34 = true;
    _model.switchValue35 = true;
    _model.switchValue36 = true;
    _model.switchValue37 = true;
    _model.switchValue38 = true;
    _model.switchValue39 = true;
    _model.switchValue40 = true;
    WidgetsBinding.instance.addPostFrameCallback((_) => setState(() {}));
  }

  @override
  void dispose() {
    _model.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () => FocusScope.of(context).unfocus(),
      child: Scaffold(
        key: scaffoldKey,
        backgroundColor: Color(0xFFFBF9F5),
        appBar: AppBar(
          backgroundColor: FlutterFlowTheme.of(context).primary,
          automaticallyImplyLeading: false,
          leading: FlutterFlowIconButton(
            borderColor: Colors.transparent,
            borderRadius: 30.0,
            borderWidth: 1.0,
            buttonSize: 60.0,
            icon: Icon(
              Icons.arrow_back_rounded,
              color: Colors.white,
              size: 30.0,
            ),
            onPressed: () async {
              context.pop();
            },
          ),
          title: Text(
            'Adaptive Test',
            style: FlutterFlowTheme.of(context).headlineMedium.override(
                  fontFamily: 'Outfit',
                  color: Colors.white,
                  fontSize: 22.0,
                  letterSpacing: 0.0,
                ),
          ),
          actions: [],
          centerTitle: false,
          elevation: 2.0,
        ),
        body: InkWell(
          splashColor: Colors.transparent,
          focusColor: Colors.transparent,
          hoverColor: Colors.transparent,
          highlightColor: Colors.transparent,
          onTap: () async {
            context.pushNamed('syllabus');
          },
          child: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.max,
              mainAxisAlignment: MainAxisAlignment.start,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Padding(
                  padding: EdgeInsetsDirectional.fromSTEB(0.0, 0.0, 16.0, 0.0),
                  child: SingleChildScrollView(
                    child: Column(
                      mainAxisSize: MainAxisSize.max,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Column(
                          mainAxisSize: MainAxisSize.max,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              '1. If the perimeter of a square is 48 cm, what is the length of one side?',
                              style: FlutterFlowTheme.of(context)
                                  .headlineSmall
                                  .override(
                                    fontFamily: 'Readex Pro',
                                    color: Colors.black,
                                    fontSize: 24.0,
                                    letterSpacing: 0.0,
                                    fontWeight: FontWeight.normal,
                                  ),
                            ),
                            Row(
                              mainAxisSize: MainAxisSize.max,
                              mainAxisAlignment: MainAxisAlignment.start,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Switch(
                                  value: _model.switchValue1!,
                                  onChanged: (newValue) async {
                                    setState(
                                        () => _model.switchValue1 = newValue!);
                                  },
                                  activeColor: Color(0xFF101518),
                                  activeTrackColor: Color(0xFF57636C),
                                  inactiveTrackColor: Color(0xFF0000FF),
                                  inactiveThumbColor: Color(0xFF57636C),
                                ),
                                Align(
                                  alignment: AlignmentDirectional(0.0, 0.0),
                                  child: Text(
                                    '\n6 cm',
                                    style: FlutterFlowTheme.of(context)
                                        .bodyMedium
                                        .override(
                                          fontFamily: 'Inter',
                                          color: FlutterFlowTheme.of(context)
                                              .tertiary,
                                          fontSize: 14.0,
                                          letterSpacing: 0.0,
                                          fontWeight: FontWeight.normal,
                                        ),
                                  ),
                                ),
                              ],
                            ),
                            Row(
                              mainAxisSize: MainAxisSize.max,
                              mainAxisAlignment: MainAxisAlignment.start,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Switch(
                                  value: _model.switchValue2!,
                                  onChanged: (newValue) async {
                                    setState(
                                        () => _model.switchValue2 = newValue!);
                                  },
                                  activeColor: Color(0xFF101518),
                                  activeTrackColor: Color(0xFF57636C),
                                  inactiveTrackColor: Color(0xFF0000FF),
                                  inactiveThumbColor: Color(0xFF57636C),
                                ),
                                Text(
                                  '\n8 cm',
                                  style: FlutterFlowTheme.of(context)
                                      .bodyMedium
                                      .override(
                                        fontFamily: 'Inter',
                                        color: FlutterFlowTheme.of(context)
                                            .tertiary,
                                        fontSize: 14.0,
                                        letterSpacing: 0.0,
                                        fontWeight: FontWeight.normal,
                                      ),
                                ),
                              ],
                            ),
                            Row(
                              mainAxisSize: MainAxisSize.max,
                              mainAxisAlignment: MainAxisAlignment.start,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Switch(
                                  value: _model.switchValue3!,
                                  onChanged: (newValue) async {
                                    setState(
                                        () => _model.switchValue3 = newValue!);
                                  },
                                  activeColor: Color(0xFF101518),
                                  activeTrackColor: Color(0xFF57636C),
                                  inactiveTrackColor: Color(0xFF0000FF),
                                  inactiveThumbColor: Color(0xFF57636C),
                                ),
                                Text(
                                  '\n12 cm',
                                  style: FlutterFlowTheme.of(context)
                                      .bodyMedium
                                      .override(
                                        fontFamily: 'Inter',
                                        color: FlutterFlowTheme.of(context)
                                            .tertiary,
                                        fontSize: 14.0,
                                        letterSpacing: 0.0,
                                        fontWeight: FontWeight.normal,
                                      ),
                                ),
                              ],
                            ),
                            Row(
                              mainAxisSize: MainAxisSize.max,
                              mainAxisAlignment: MainAxisAlignment.start,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Switch(
                                  value: _model.switchValue4!,
                                  onChanged: (newValue) async {
                                    setState(
                                        () => _model.switchValue4 = newValue!);
                                  },
                                  activeColor: Color(0xFF101518),
                                  activeTrackColor: Color(0xFF57636C),
                                  inactiveTrackColor: Color(0xFF0000FF),
                                  inactiveThumbColor: Color(0xFF57636C),
                                ),
                                Text(
                                  '\n16 cm',
                                  style: FlutterFlowTheme.of(context)
                                      .bodyMedium
                                      .override(
                                        fontFamily: 'Inter',
                                        color: FlutterFlowTheme.of(context)
                                            .tertiary,
                                        fontSize: 14.0,
                                        letterSpacing: 0.0,
                                        fontWeight: FontWeight.normal,
                                      ),
                                ),
                              ],
                            ),
                          ].divide(SizedBox(height: 8.0)),
                        ),
                        Column(
                          mainAxisSize: MainAxisSize.max,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              '\n2.  Which of the following is a non-contact force?',
                              style: FlutterFlowTheme.of(context)
                                  .headlineSmall
                                  .override(
                                    fontFamily: 'Readex Pro',
                                    color: Colors.black,
                                    fontSize: 24.0,
                                    letterSpacing: 0.0,
                                    fontWeight: FontWeight.normal,
                                  ),
                            ),
                            Row(
                              mainAxisSize: MainAxisSize.max,
                              mainAxisAlignment: MainAxisAlignment.start,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Switch(
                                  value: _model.switchValue5!,
                                  onChanged: (newValue) async {
                                    setState(
                                        () => _model.switchValue5 = newValue!);
                                  },
                                  activeColor: Color(0xFF101518),
                                  activeTrackColor: Color(0xFF57636C),
                                  inactiveTrackColor: Color(0xFF0000FF),
                                  inactiveThumbColor: Color(0xFF57636C),
                                ),
                                Text(
                                  '\nFrictional force',
                                  style: FlutterFlowTheme.of(context)
                                      .bodyMedium
                                      .override(
                                        fontFamily: 'Inter',
                                        color: FlutterFlowTheme.of(context)
                                            .tertiary,
                                        fontSize: 14.0,
                                        letterSpacing: 0.0,
                                        fontWeight: FontWeight.normal,
                                      ),
                                ),
                              ],
                            ),
                            Row(
                              mainAxisSize: MainAxisSize.max,
                              mainAxisAlignment: MainAxisAlignment.start,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Switch(
                                  value: _model.switchValue6!,
                                  onChanged: (newValue) async {
                                    setState(
                                        () => _model.switchValue6 = newValue!);
                                  },
                                  activeColor: Color(0xFF101518),
                                  activeTrackColor: Color(0xFF57636C),
                                  inactiveTrackColor: Color(0xFF0000FF),
                                  inactiveThumbColor: Color(0xFF57636C),
                                ),
                                Text(
                                  '\nGravitational force',
                                  style: FlutterFlowTheme.of(context)
                                      .bodyMedium
                                      .override(
                                        fontFamily: 'Inter',
                                        color: FlutterFlowTheme.of(context)
                                            .tertiary,
                                        fontSize: 14.0,
                                        letterSpacing: 0.0,
                                        fontWeight: FontWeight.normal,
                                      ),
                                ),
                              ],
                            ),
                            Row(
                              mainAxisSize: MainAxisSize.max,
                              mainAxisAlignment: MainAxisAlignment.start,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Switch(
                                  value: _model.switchValue7!,
                                  onChanged: (newValue) async {
                                    setState(
                                        () => _model.switchValue7 = newValue!);
                                  },
                                  activeColor: Color(0xFF101518),
                                  activeTrackColor: Color(0xFF57636C),
                                  inactiveTrackColor: Color(0xFF0000FF),
                                  inactiveThumbColor: Color(0xFF57636C),
                                ),
                                Text(
                                  '\nMuscular force',
                                  style: FlutterFlowTheme.of(context)
                                      .bodyMedium
                                      .override(
                                        fontFamily: 'Inter',
                                        color: FlutterFlowTheme.of(context)
                                            .tertiary,
                                        fontSize: 14.0,
                                        letterSpacing: 0.0,
                                        fontWeight: FontWeight.normal,
                                      ),
                                ),
                              ],
                            ),
                            Row(
                              mainAxisSize: MainAxisSize.max,
                              mainAxisAlignment: MainAxisAlignment.start,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Switch(
                                  value: _model.switchValue8!,
                                  onChanged: (newValue) async {
                                    setState(
                                        () => _model.switchValue8 = newValue!);
                                  },
                                  activeColor: Color(0xFF101518),
                                  activeTrackColor: Color(0xFF57636C),
                                  inactiveTrackColor: Color(0xFF0000FF),
                                  inactiveThumbColor: Color(0xFF57636C),
                                ),
                                Text(
                                  '\nTension force ',
                                  style: FlutterFlowTheme.of(context)
                                      .bodyMedium
                                      .override(
                                        fontFamily: 'Inter',
                                        color: FlutterFlowTheme.of(context)
                                            .tertiary,
                                        fontSize: 14.0,
                                        letterSpacing: 0.0,
                                        fontWeight: FontWeight.normal,
                                      ),
                                ),
                              ],
                            ),
                          ].divide(SizedBox(height: 8.0)),
                        ),
                        Column(
                          mainAxisSize: MainAxisSize.max,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              '\n3. What is the function of the human heart?',
                              style: FlutterFlowTheme.of(context)
                                  .headlineSmall
                                  .override(
                                    fontFamily: 'Readex Pro',
                                    color: Colors.black,
                                    fontSize: 24.0,
                                    letterSpacing: 0.0,
                                    fontWeight: FontWeight.normal,
                                  ),
                            ),
                            Row(
                              mainAxisSize: MainAxisSize.max,
                              mainAxisAlignment: MainAxisAlignment.start,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Switch(
                                  value: _model.switchValue9!,
                                  onChanged: (newValue) async {
                                    setState(
                                        () => _model.switchValue9 = newValue!);
                                  },
                                  activeColor: Color(0xFF101518),
                                  activeTrackColor: Color(0xFF57636C),
                                  inactiveTrackColor: Color(0xFF0000FF),
                                  inactiveThumbColor: Color(0xFF57636C),
                                ),
                                Text(
                                  '\nTo filter blood\n',
                                  style: FlutterFlowTheme.of(context)
                                      .bodyMedium
                                      .override(
                                        fontFamily: 'Inter',
                                        color: FlutterFlowTheme.of(context)
                                            .tertiary,
                                        fontSize: 14.0,
                                        letterSpacing: 0.0,
                                        fontWeight: FontWeight.normal,
                                      ),
                                ),
                              ],
                            ),
                            Row(
                              mainAxisSize: MainAxisSize.max,
                              mainAxisAlignment: MainAxisAlignment.start,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Switch(
                                  value: _model.switchValue10!,
                                  onChanged: (newValue) async {
                                    setState(
                                        () => _model.switchValue10 = newValue!);
                                  },
                                  activeColor: Color(0xFF101518),
                                  activeTrackColor: Color(0xFF57636C),
                                  inactiveTrackColor: Color(0xFF0000FF),
                                  inactiveThumbColor: Color(0xFF57636C),
                                ),
                                Text(
                                  '\nTo pump blood throughout the body',
                                  style: FlutterFlowTheme.of(context)
                                      .bodyMedium
                                      .override(
                                        fontFamily: 'Inter',
                                        color: FlutterFlowTheme.of(context)
                                            .tertiary,
                                        fontSize: 14.0,
                                        letterSpacing: 0.0,
                                        fontWeight: FontWeight.normal,
                                      ),
                                ),
                              ],
                            ),
                            Row(
                              mainAxisSize: MainAxisSize.max,
                              mainAxisAlignment: MainAxisAlignment.start,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Switch(
                                  value: _model.switchValue11!,
                                  onChanged: (newValue) async {
                                    setState(
                                        () => _model.switchValue11 = newValue!);
                                  },
                                  activeColor: Color(0xFF101518),
                                  activeTrackColor: Color(0xFF57636C),
                                  inactiveTrackColor: Color(0xFF0000FF),
                                  inactiveThumbColor: Color(0xFF57636C),
                                ),
                                Text(
                                  '\nTo produce digestive enzymes',
                                  style: FlutterFlowTheme.of(context)
                                      .bodyMedium
                                      .override(
                                        fontFamily: 'Inter',
                                        color: FlutterFlowTheme.of(context)
                                            .tertiary,
                                        fontSize: 14.0,
                                        letterSpacing: 0.0,
                                        fontWeight: FontWeight.normal,
                                      ),
                                ),
                              ],
                            ),
                            Row(
                              mainAxisSize: MainAxisSize.max,
                              mainAxisAlignment: MainAxisAlignment.start,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Switch(
                                  value: _model.switchValue12!,
                                  onChanged: (newValue) async {
                                    setState(
                                        () => _model.switchValue12 = newValue!);
                                  },
                                  activeColor: Color(0xFF101518),
                                  activeTrackColor: Color(0xFF57636C),
                                  inactiveTrackColor: Color(0xFF0000FF),
                                  inactiveThumbColor: Color(0xFF57636C),
                                ),
                                Text(
                                  '\n To store oxygen ',
                                  style: FlutterFlowTheme.of(context)
                                      .bodyMedium
                                      .override(
                                        fontFamily: 'Inter',
                                        color: FlutterFlowTheme.of(context)
                                            .tertiary,
                                        fontSize: 14.0,
                                        letterSpacing: 0.0,
                                        fontWeight: FontWeight.normal,
                                      ),
                                ),
                              ],
                            ),
                          ].divide(SizedBox(height: 8.0)),
                        ),
                        Column(
                          mainAxisSize: MainAxisSize.max,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              '\n4.  Who was the first President of India?',
                              style: FlutterFlowTheme.of(context)
                                  .headlineSmall
                                  .override(
                                    fontFamily: 'Readex Pro',
                                    color: Colors.black,
                                    fontSize: 24.0,
                                    letterSpacing: 0.0,
                                    fontWeight: FontWeight.normal,
                                  ),
                            ),
                            Row(
                              mainAxisSize: MainAxisSize.max,
                              mainAxisAlignment: MainAxisAlignment.start,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Switch(
                                  value: _model.switchValue13!,
                                  onChanged: (newValue) async {
                                    setState(
                                        () => _model.switchValue13 = newValue!);
                                  },
                                  activeColor: Color(0xFF101518),
                                  activeTrackColor: Color(0xFF57636C),
                                  inactiveTrackColor: Color(0xFF0000FF),
                                  inactiveThumbColor: Color(0xFF57636C),
                                ),
                                Text(
                                  '\nMahatma Gandhi',
                                  style: FlutterFlowTheme.of(context)
                                      .bodyMedium
                                      .override(
                                        fontFamily: 'Inter',
                                        color: FlutterFlowTheme.of(context)
                                            .tertiary,
                                        fontSize: 14.0,
                                        letterSpacing: 0.0,
                                        fontWeight: FontWeight.normal,
                                      ),
                                ),
                              ],
                            ),
                            Row(
                              mainAxisSize: MainAxisSize.max,
                              mainAxisAlignment: MainAxisAlignment.start,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Switch(
                                  value: _model.switchValue14!,
                                  onChanged: (newValue) async {
                                    setState(
                                        () => _model.switchValue14 = newValue!);
                                  },
                                  activeColor: Color(0xFF101518),
                                  activeTrackColor: Color(0xFF57636C),
                                  inactiveTrackColor: Color(0xFF0000FF),
                                  inactiveThumbColor: Color(0xFF57636C),
                                ),
                                Text(
                                  '\nJawaharlal Nehru',
                                  style: FlutterFlowTheme.of(context)
                                      .bodyMedium
                                      .override(
                                        fontFamily: 'Inter',
                                        color: FlutterFlowTheme.of(context)
                                            .tertiary,
                                        fontSize: 14.0,
                                        letterSpacing: 0.0,
                                        fontWeight: FontWeight.normal,
                                      ),
                                ),
                              ],
                            ),
                            Row(
                              mainAxisSize: MainAxisSize.max,
                              mainAxisAlignment: MainAxisAlignment.start,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Switch(
                                  value: _model.switchValue15!,
                                  onChanged: (newValue) async {
                                    setState(
                                        () => _model.switchValue15 = newValue!);
                                  },
                                  activeColor: Color(0xFF101518),
                                  activeTrackColor: Color(0xFF57636C),
                                  inactiveTrackColor: Color(0xFF0000FF),
                                  inactiveThumbColor: Color(0xFF57636C),
                                ),
                                Text(
                                  '\nDr. B.R. Ambedkar',
                                  style: FlutterFlowTheme.of(context)
                                      .bodyMedium
                                      .override(
                                        fontFamily: 'Inter',
                                        color: FlutterFlowTheme.of(context)
                                            .tertiary,
                                        fontSize: 14.0,
                                        letterSpacing: 0.0,
                                        fontWeight: FontWeight.normal,
                                      ),
                                ),
                              ],
                            ),
                            Row(
                              mainAxisSize: MainAxisSize.max,
                              mainAxisAlignment: MainAxisAlignment.start,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Switch(
                                  value: _model.switchValue16!,
                                  onChanged: (newValue) async {
                                    setState(
                                        () => _model.switchValue16 = newValue!);
                                  },
                                  activeColor: Color(0xFF101518),
                                  activeTrackColor: Color(0xFF57636C),
                                  inactiveTrackColor: Color(0xFF0000FF),
                                  inactiveThumbColor: Color(0xFF57636C),
                                ),
                                Text(
                                  '\nDr. Rajendra Prasad ',
                                  style: FlutterFlowTheme.of(context)
                                      .bodyMedium
                                      .override(
                                        fontFamily: 'Inter',
                                        color: FlutterFlowTheme.of(context)
                                            .tertiary,
                                        fontSize: 14.0,
                                        letterSpacing: 0.0,
                                        fontWeight: FontWeight.normal,
                                      ),
                                ),
                              ],
                            ),
                          ].divide(SizedBox(height: 8.0)),
                        ),
                        Column(
                          mainAxisSize: MainAxisSize.max,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              '\n5. Which of the following is a chemical change?',
                              style: FlutterFlowTheme.of(context)
                                  .headlineSmall
                                  .override(
                                    fontFamily: 'Readex Pro',
                                    color: Colors.black,
                                    fontSize: 24.0,
                                    letterSpacing: 0.0,
                                    fontWeight: FontWeight.normal,
                                  ),
                            ),
                            Row(
                              mainAxisSize: MainAxisSize.max,
                              mainAxisAlignment: MainAxisAlignment.start,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Switch(
                                  value: _model.switchValue17!,
                                  onChanged: (newValue) async {
                                    setState(
                                        () => _model.switchValue17 = newValue!);
                                  },
                                  activeColor: Color(0xFF101518),
                                  activeTrackColor: Color(0xFF57636C),
                                  inactiveTrackColor: Color(0xFF0000FF),
                                  inactiveThumbColor: Color(0xFF57636C),
                                ),
                                Text(
                                  '\nMelting of ice',
                                  style: FlutterFlowTheme.of(context)
                                      .bodyMedium
                                      .override(
                                        fontFamily: 'Inter',
                                        color: FlutterFlowTheme.of(context)
                                            .tertiary,
                                        fontSize: 14.0,
                                        letterSpacing: 0.0,
                                        fontWeight: FontWeight.normal,
                                      ),
                                ),
                              ],
                            ),
                            Row(
                              mainAxisSize: MainAxisSize.max,
                              mainAxisAlignment: MainAxisAlignment.start,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Switch(
                                  value: _model.switchValue18!,
                                  onChanged: (newValue) async {
                                    setState(
                                        () => _model.switchValue18 = newValue!);
                                  },
                                  activeColor: Color(0xFF101518),
                                  activeTrackColor: Color(0xFF57636C),
                                  inactiveTrackColor: Color(0xFF0000FF),
                                  inactiveThumbColor: Color(0xFF57636C),
                                ),
                                Text(
                                  '\nRusting of iron',
                                  style: FlutterFlowTheme.of(context)
                                      .bodyMedium
                                      .override(
                                        fontFamily: 'Inter',
                                        color: FlutterFlowTheme.of(context)
                                            .tertiary,
                                        fontSize: 14.0,
                                        letterSpacing: 0.0,
                                        fontWeight: FontWeight.normal,
                                      ),
                                ),
                              ],
                            ),
                            Row(
                              mainAxisSize: MainAxisSize.max,
                              mainAxisAlignment: MainAxisAlignment.start,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Switch(
                                  value: _model.switchValue19!,
                                  onChanged: (newValue) async {
                                    setState(
                                        () => _model.switchValue19 = newValue!);
                                  },
                                  activeColor: Color(0xFF101518),
                                  activeTrackColor: Color(0xFF57636C),
                                  inactiveTrackColor: Color(0xFF0000FF),
                                  inactiveThumbColor: Color(0xFF57636C),
                                ),
                                Text(
                                  '\nTearing of paper',
                                  style: FlutterFlowTheme.of(context)
                                      .bodyMedium
                                      .override(
                                        fontFamily: 'Inter',
                                        color: FlutterFlowTheme.of(context)
                                            .tertiary,
                                        fontSize: 14.0,
                                        letterSpacing: 0.0,
                                        fontWeight: FontWeight.normal,
                                      ),
                                ),
                              ],
                            ),
                            Row(
                              mainAxisSize: MainAxisSize.max,
                              mainAxisAlignment: MainAxisAlignment.start,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Switch(
                                  value: _model.switchValue20!,
                                  onChanged: (newValue) async {
                                    setState(
                                        () => _model.switchValue20 = newValue!);
                                  },
                                  activeColor: Color(0xFF101518),
                                  activeTrackColor: Color(0xFF57636C),
                                  inactiveTrackColor: Color(0xFF0000FF),
                                  inactiveThumbColor: Color(0xFF57636C),
                                ),
                                Text(
                                  '\nBoiling of water',
                                  style: FlutterFlowTheme.of(context)
                                      .bodyMedium
                                      .override(
                                        fontFamily: 'Inter',
                                        color: FlutterFlowTheme.of(context)
                                            .tertiary,
                                        fontSize: 14.0,
                                        letterSpacing: 0.0,
                                        fontWeight: FontWeight.normal,
                                      ),
                                ),
                              ],
                            ),
                          ].divide(SizedBox(height: 8.0)),
                        ),
                        Column(
                          mainAxisSize: MainAxisSize.max,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              '\n6. Which of the following is the correct plural form of \"child\"?',
                              style: FlutterFlowTheme.of(context)
                                  .headlineSmall
                                  .override(
                                    fontFamily: 'Readex Pro',
                                    color: Colors.black,
                                    fontSize: 24.0,
                                    letterSpacing: 0.0,
                                    fontWeight: FontWeight.normal,
                                  ),
                            ),
                            Row(
                              mainAxisSize: MainAxisSize.max,
                              mainAxisAlignment: MainAxisAlignment.start,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Switch(
                                  value: _model.switchValue21!,
                                  onChanged: (newValue) async {
                                    setState(
                                        () => _model.switchValue21 = newValue!);
                                  },
                                  activeColor: Color(0xFF101518),
                                  activeTrackColor: Color(0xFF57636C),
                                  inactiveTrackColor: Color(0xFF0000FF),
                                  inactiveThumbColor: Color(0xFF57636C),
                                ),
                                Text(
                                  '\nChilds',
                                  style: FlutterFlowTheme.of(context)
                                      .bodyMedium
                                      .override(
                                        fontFamily: 'Inter',
                                        color: FlutterFlowTheme.of(context)
                                            .tertiary,
                                        fontSize: 14.0,
                                        letterSpacing: 0.0,
                                        fontWeight: FontWeight.normal,
                                      ),
                                ),
                              ],
                            ),
                            Row(
                              mainAxisSize: MainAxisSize.max,
                              mainAxisAlignment: MainAxisAlignment.start,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Switch(
                                  value: _model.switchValue22!,
                                  onChanged: (newValue) async {
                                    setState(
                                        () => _model.switchValue22 = newValue!);
                                  },
                                  activeColor: Color(0xFF101518),
                                  activeTrackColor: Color(0xFF57636C),
                                  inactiveTrackColor: Color(0xFF0000FF),
                                  inactiveThumbColor: Color(0xFF57636C),
                                ),
                                Text(
                                  '\nChildrens',
                                  style: FlutterFlowTheme.of(context)
                                      .bodyMedium
                                      .override(
                                        fontFamily: 'Inter',
                                        color: FlutterFlowTheme.of(context)
                                            .tertiary,
                                        fontSize: 14.0,
                                        letterSpacing: 0.0,
                                        fontWeight: FontWeight.normal,
                                      ),
                                ),
                              ],
                            ),
                            Row(
                              mainAxisSize: MainAxisSize.max,
                              mainAxisAlignment: MainAxisAlignment.start,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Switch(
                                  value: _model.switchValue23!,
                                  onChanged: (newValue) async {
                                    setState(
                                        () => _model.switchValue23 = newValue!);
                                  },
                                  activeColor: Color(0xFF101518),
                                  activeTrackColor: Color(0xFF57636C),
                                  inactiveTrackColor: Color(0xFF0000FF),
                                  inactiveThumbColor: Color(0xFF57636C),
                                ),
                                Text(
                                  '\nChildes',
                                  style: FlutterFlowTheme.of(context)
                                      .bodyMedium
                                      .override(
                                        fontFamily: 'Inter',
                                        color: FlutterFlowTheme.of(context)
                                            .tertiary,
                                        fontSize: 14.0,
                                        letterSpacing: 0.0,
                                        fontWeight: FontWeight.normal,
                                      ),
                                ),
                              ],
                            ),
                            Row(
                              mainAxisSize: MainAxisSize.max,
                              mainAxisAlignment: MainAxisAlignment.start,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Switch(
                                  value: _model.switchValue24!,
                                  onChanged: (newValue) async {
                                    setState(
                                        () => _model.switchValue24 = newValue!);
                                  },
                                  activeColor: Color(0xFF101518),
                                  activeTrackColor: Color(0xFF57636C),
                                  inactiveTrackColor: Color(0xFF0000FF),
                                  inactiveThumbColor: Color(0xFF57636C),
                                ),
                                Text(
                                  '\nChildren',
                                  style: FlutterFlowTheme.of(context)
                                      .bodyMedium
                                      .override(
                                        fontFamily: 'Inter',
                                        color: FlutterFlowTheme.of(context)
                                            .tertiary,
                                        fontSize: 14.0,
                                        letterSpacing: 0.0,
                                        fontWeight: FontWeight.normal,
                                      ),
                                ),
                              ],
                            ),
                          ].divide(SizedBox(height: 8.0)),
                        ),
                        Column(
                          mainAxisSize: MainAxisSize.max,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              '\n7.  Which of these is a renewable source of energy?',
                              style: FlutterFlowTheme.of(context)
                                  .headlineSmall
                                  .override(
                                    fontFamily: 'Readex Pro',
                                    color: Colors.black,
                                    fontSize: 24.0,
                                    letterSpacing: 0.0,
                                    fontWeight: FontWeight.normal,
                                  ),
                            ),
                            Row(
                              mainAxisSize: MainAxisSize.max,
                              mainAxisAlignment: MainAxisAlignment.start,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Switch(
                                  value: _model.switchValue25!,
                                  onChanged: (newValue) async {
                                    setState(
                                        () => _model.switchValue25 = newValue!);
                                  },
                                  activeColor: Color(0xFF101518),
                                  activeTrackColor: Color(0xFF57636C),
                                  inactiveTrackColor: Color(0xFF0000FF),
                                  inactiveThumbColor: Color(0xFF57636C),
                                ),
                                Text(
                                  '\nCoal',
                                  style: FlutterFlowTheme.of(context)
                                      .bodyMedium
                                      .override(
                                        fontFamily: 'Inter',
                                        color: FlutterFlowTheme.of(context)
                                            .tertiary,
                                        fontSize: 14.0,
                                        letterSpacing: 0.0,
                                        fontWeight: FontWeight.normal,
                                      ),
                                ),
                              ],
                            ),
                            Row(
                              mainAxisSize: MainAxisSize.max,
                              mainAxisAlignment: MainAxisAlignment.start,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Switch(
                                  value: _model.switchValue26!,
                                  onChanged: (newValue) async {
                                    setState(
                                        () => _model.switchValue26 = newValue!);
                                  },
                                  activeColor: Color(0xFF101518),
                                  activeTrackColor: Color(0xFF57636C),
                                  inactiveTrackColor: Color(0xFF0000FF),
                                  inactiveThumbColor: Color(0xFF57636C),
                                ),
                                Text(
                                  '\nOil',
                                  style: FlutterFlowTheme.of(context)
                                      .bodyMedium
                                      .override(
                                        fontFamily: 'Inter',
                                        color: FlutterFlowTheme.of(context)
                                            .tertiary,
                                        fontSize: 14.0,
                                        letterSpacing: 0.0,
                                        fontWeight: FontWeight.normal,
                                      ),
                                ),
                              ],
                            ),
                            Row(
                              mainAxisSize: MainAxisSize.max,
                              mainAxisAlignment: MainAxisAlignment.start,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Switch(
                                  value: _model.switchValue27!,
                                  onChanged: (newValue) async {
                                    setState(
                                        () => _model.switchValue27 = newValue!);
                                  },
                                  activeColor: Color(0xFF101518),
                                  activeTrackColor: Color(0xFF57636C),
                                  inactiveTrackColor: Color(0xFF0000FF),
                                  inactiveThumbColor: Color(0xFF57636C),
                                ),
                                Text(
                                  '\nSolar energy',
                                  style: FlutterFlowTheme.of(context)
                                      .bodyMedium
                                      .override(
                                        fontFamily: 'Inter',
                                        color: FlutterFlowTheme.of(context)
                                            .tertiary,
                                        fontSize: 14.0,
                                        letterSpacing: 0.0,
                                        fontWeight: FontWeight.normal,
                                      ),
                                ),
                              ],
                            ),
                            Row(
                              mainAxisSize: MainAxisSize.max,
                              mainAxisAlignment: MainAxisAlignment.start,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Switch(
                                  value: _model.switchValue28!,
                                  onChanged: (newValue) async {
                                    setState(
                                        () => _model.switchValue28 = newValue!);
                                  },
                                  activeColor: Color(0xFF101518),
                                  activeTrackColor: Color(0xFF57636C),
                                  inactiveTrackColor: Color(0xFF0000FF),
                                  inactiveThumbColor: Color(0xFF57636C),
                                ),
                                Text(
                                  '\nNatural gas',
                                  style: FlutterFlowTheme.of(context)
                                      .bodyMedium
                                      .override(
                                        fontFamily: 'Inter',
                                        color: FlutterFlowTheme.of(context)
                                            .tertiary,
                                        fontSize: 14.0,
                                        letterSpacing: 0.0,
                                        fontWeight: FontWeight.normal,
                                      ),
                                ),
                              ],
                            ),
                          ].divide(SizedBox(height: 8.0)),
                        ),
                        Column(
                          mainAxisSize: MainAxisSize.max,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              '\n8. Which of the following events is associated with 1857 in India?',
                              style: FlutterFlowTheme.of(context)
                                  .headlineSmall
                                  .override(
                                    fontFamily: 'Readex Pro',
                                    color: Colors.black,
                                    fontSize: 24.0,
                                    letterSpacing: 0.0,
                                    fontWeight: FontWeight.normal,
                                  ),
                            ),
                            Row(
                              mainAxisSize: MainAxisSize.max,
                              mainAxisAlignment: MainAxisAlignment.start,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Switch(
                                  value: _model.switchValue29!,
                                  onChanged: (newValue) async {
                                    setState(
                                        () => _model.switchValue29 = newValue!);
                                  },
                                  activeColor: Color(0xFF101518),
                                  activeTrackColor: Color(0xFF57636C),
                                  inactiveTrackColor: Color(0xFF0000FF),
                                  inactiveThumbColor: Color(0xFF57636C),
                                ),
                                Text(
                                  '\nThe Battle of Plassey',
                                  style: FlutterFlowTheme.of(context)
                                      .bodyMedium
                                      .override(
                                        fontFamily: 'Inter',
                                        color: FlutterFlowTheme.of(context)
                                            .tertiary,
                                        fontSize: 14.0,
                                        letterSpacing: 0.0,
                                        fontWeight: FontWeight.normal,
                                      ),
                                ),
                              ],
                            ),
                            Row(
                              mainAxisSize: MainAxisSize.max,
                              mainAxisAlignment: MainAxisAlignment.start,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Switch(
                                  value: _model.switchValue30!,
                                  onChanged: (newValue) async {
                                    setState(
                                        () => _model.switchValue30 = newValue!);
                                  },
                                  activeColor: Color(0xFF101518),
                                  activeTrackColor: Color(0xFF57636C),
                                  inactiveTrackColor: Color(0xFF0000FF),
                                  inactiveThumbColor: Color(0xFF57636C),
                                ),
                                Text(
                                  '\nThe Revolt of 1857',
                                  style: FlutterFlowTheme.of(context)
                                      .bodyMedium
                                      .override(
                                        fontFamily: 'Inter',
                                        color: FlutterFlowTheme.of(context)
                                            .tertiary,
                                        fontSize: 14.0,
                                        letterSpacing: 0.0,
                                        fontWeight: FontWeight.normal,
                                      ),
                                ),
                              ],
                            ),
                            Row(
                              mainAxisSize: MainAxisSize.max,
                              mainAxisAlignment: MainAxisAlignment.start,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Switch(
                                  value: _model.switchValue31!,
                                  onChanged: (newValue) async {
                                    setState(
                                        () => _model.switchValue31 = newValue!);
                                  },
                                  activeColor: Color(0xFF101518),
                                  activeTrackColor: Color(0xFF57636C),
                                  inactiveTrackColor: Color(0xFF0000FF),
                                  inactiveThumbColor: Color(0xFF57636C),
                                ),
                                Text(
                                  '\nThe Jallianwala Bagh Massacre',
                                  style: FlutterFlowTheme.of(context)
                                      .bodyMedium
                                      .override(
                                        fontFamily: 'Inter',
                                        color: FlutterFlowTheme.of(context)
                                            .tertiary,
                                        fontSize: 14.0,
                                        letterSpacing: 0.0,
                                        fontWeight: FontWeight.normal,
                                      ),
                                ),
                              ],
                            ),
                            Row(
                              mainAxisSize: MainAxisSize.max,
                              mainAxisAlignment: MainAxisAlignment.start,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Switch(
                                  value: _model.switchValue32!,
                                  onChanged: (newValue) async {
                                    setState(
                                        () => _model.switchValue32 = newValue!);
                                  },
                                  activeColor: Color(0xFF101518),
                                  activeTrackColor: Color(0xFF57636C),
                                  inactiveTrackColor: Color(0xFF0000FF),
                                  inactiveThumbColor: Color(0xFF57636C),
                                ),
                                Text(
                                  '\nThe Salt March  ',
                                  style: FlutterFlowTheme.of(context)
                                      .bodyMedium
                                      .override(
                                        fontFamily: 'Inter',
                                        color: FlutterFlowTheme.of(context)
                                            .tertiary,
                                        fontSize: 14.0,
                                        letterSpacing: 0.0,
                                        fontWeight: FontWeight.normal,
                                      ),
                                ),
                              ],
                            ),
                          ].divide(SizedBox(height: 8.0)),
                        ),
                        Column(
                          mainAxisSize: MainAxisSize.max,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              '\n9. QWhich of the following is the longest river in the world?',
                              style: FlutterFlowTheme.of(context)
                                  .headlineSmall
                                  .override(
                                    fontFamily: 'Readex Pro',
                                    color: Colors.black,
                                    fontSize: 24.0,
                                    letterSpacing: 0.0,
                                    fontWeight: FontWeight.normal,
                                  ),
                            ),
                            Row(
                              mainAxisSize: MainAxisSize.max,
                              mainAxisAlignment: MainAxisAlignment.start,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Switch(
                                  value: _model.switchValue33!,
                                  onChanged: (newValue) async {
                                    setState(
                                        () => _model.switchValue33 = newValue!);
                                  },
                                  activeColor: Color(0xFF101518),
                                  activeTrackColor: Color(0xFF57636C),
                                  inactiveTrackColor: Color(0xFF0000FF),
                                  inactiveThumbColor: Color(0xFF57636C),
                                ),
                                Text(
                                  '\nAmazon',
                                  style: FlutterFlowTheme.of(context)
                                      .bodyMedium
                                      .override(
                                        fontFamily: 'Inter',
                                        color: FlutterFlowTheme.of(context)
                                            .tertiary,
                                        fontSize: 14.0,
                                        letterSpacing: 0.0,
                                        fontWeight: FontWeight.normal,
                                      ),
                                ),
                              ],
                            ),
                            Row(
                              mainAxisSize: MainAxisSize.max,
                              mainAxisAlignment: MainAxisAlignment.start,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Switch(
                                  value: _model.switchValue34!,
                                  onChanged: (newValue) async {
                                    setState(
                                        () => _model.switchValue34 = newValue!);
                                  },
                                  activeColor: Color(0xFF101518),
                                  activeTrackColor: Color(0xFF57636C),
                                  inactiveTrackColor: Color(0xFF0000FF),
                                  inactiveThumbColor: Color(0xFF57636C),
                                ),
                                Text(
                                  '\nNile',
                                  style: FlutterFlowTheme.of(context)
                                      .bodyMedium
                                      .override(
                                        fontFamily: 'Inter',
                                        color: FlutterFlowTheme.of(context)
                                            .tertiary,
                                        fontSize: 14.0,
                                        letterSpacing: 0.0,
                                        fontWeight: FontWeight.normal,
                                      ),
                                ),
                              ],
                            ),
                            Row(
                              mainAxisSize: MainAxisSize.max,
                              mainAxisAlignment: MainAxisAlignment.start,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Switch(
                                  value: _model.switchValue35!,
                                  onChanged: (newValue) async {
                                    setState(
                                        () => _model.switchValue35 = newValue!);
                                  },
                                  activeColor: Color(0xFF101518),
                                  activeTrackColor: Color(0xFF57636C),
                                  inactiveTrackColor: Color(0xFF0000FF),
                                  inactiveThumbColor: Color(0xFF57636C),
                                ),
                                Text(
                                  '\nYangtze',
                                  style: FlutterFlowTheme.of(context)
                                      .bodyMedium
                                      .override(
                                        fontFamily: 'Inter',
                                        color: FlutterFlowTheme.of(context)
                                            .tertiary,
                                        fontSize: 14.0,
                                        letterSpacing: 0.0,
                                        fontWeight: FontWeight.normal,
                                      ),
                                ),
                              ],
                            ),
                            Row(
                              mainAxisSize: MainAxisSize.max,
                              mainAxisAlignment: MainAxisAlignment.start,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Switch(
                                  value: _model.switchValue36!,
                                  onChanged: (newValue) async {
                                    setState(
                                        () => _model.switchValue36 = newValue!);
                                  },
                                  activeColor: Color(0xFF101518),
                                  activeTrackColor: Color(0xFF57636C),
                                  inactiveTrackColor: Color(0xFF0000FF),
                                  inactiveThumbColor: Color(0xFF57636C),
                                ),
                                Text(
                                  '\nMississippi',
                                  style: FlutterFlowTheme.of(context)
                                      .bodyMedium
                                      .override(
                                        fontFamily: 'Inter',
                                        color: FlutterFlowTheme.of(context)
                                            .tertiary,
                                        fontSize: 14.0,
                                        letterSpacing: 0.0,
                                        fontWeight: FontWeight.normal,
                                      ),
                                ),
                              ],
                            ),
                          ].divide(SizedBox(height: 8.0)),
                        ),
                        Column(
                          mainAxisSize: MainAxisSize.max,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              '\n10. Who invented the telephone?',
                              style: FlutterFlowTheme.of(context)
                                  .headlineSmall
                                  .override(
                                    fontFamily: 'Readex Pro',
                                    color: Colors.black,
                                    fontSize: 24.0,
                                    letterSpacing: 0.0,
                                    fontWeight: FontWeight.normal,
                                  ),
                            ),
                            Row(
                              mainAxisSize: MainAxisSize.max,
                              mainAxisAlignment: MainAxisAlignment.start,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Switch(
                                  value: _model.switchValue37!,
                                  onChanged: (newValue) async {
                                    setState(
                                        () => _model.switchValue37 = newValue!);
                                  },
                                  activeColor: Color(0xFF101518),
                                  activeTrackColor: Color(0xFF57636C),
                                  inactiveTrackColor: Color(0xFF0000FF),
                                  inactiveThumbColor: Color(0xFF57636C),
                                ),
                                Text(
                                  '\nThomas Edison',
                                  style: FlutterFlowTheme.of(context)
                                      .bodyMedium
                                      .override(
                                        fontFamily: 'Inter',
                                        color: FlutterFlowTheme.of(context)
                                            .tertiary,
                                        fontSize: 14.0,
                                        letterSpacing: 0.0,
                                        fontWeight: FontWeight.normal,
                                      ),
                                ),
                              ],
                            ),
                            Row(
                              mainAxisSize: MainAxisSize.max,
                              mainAxisAlignment: MainAxisAlignment.start,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Switch(
                                  value: _model.switchValue38!,
                                  onChanged: (newValue) async {
                                    setState(
                                        () => _model.switchValue38 = newValue!);
                                  },
                                  activeColor: Color(0xFF101518),
                                  activeTrackColor: Color(0xFF57636C),
                                  inactiveTrackColor: Color(0xFF0000FF),
                                  inactiveThumbColor: Color(0xFF57636C),
                                ),
                                Text(
                                  '\nAlexander Graham Bell',
                                  style: FlutterFlowTheme.of(context)
                                      .bodyMedium
                                      .override(
                                        fontFamily: 'Inter',
                                        color: FlutterFlowTheme.of(context)
                                            .tertiary,
                                        fontSize: 14.0,
                                        letterSpacing: 0.0,
                                        fontWeight: FontWeight.normal,
                                      ),
                                ),
                              ],
                            ),
                            Row(
                              mainAxisSize: MainAxisSize.max,
                              mainAxisAlignment: MainAxisAlignment.start,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Switch(
                                  value: _model.switchValue39!,
                                  onChanged: (newValue) async {
                                    setState(
                                        () => _model.switchValue39 = newValue!);
                                  },
                                  activeColor: Color(0xFF101518),
                                  activeTrackColor: Color(0xFF57636C),
                                  inactiveTrackColor: Color(0xFF0000FF),
                                  inactiveThumbColor: Color(0xFF57636C),
                                ),
                                Text(
                                  '\n Nikola Tesla',
                                  style: FlutterFlowTheme.of(context)
                                      .bodyMedium
                                      .override(
                                        fontFamily: 'Inter',
                                        color: FlutterFlowTheme.of(context)
                                            .tertiary,
                                        fontSize: 14.0,
                                        letterSpacing: 0.0,
                                        fontWeight: FontWeight.normal,
                                      ),
                                ),
                              ],
                            ),
                            Row(
                              mainAxisSize: MainAxisSize.max,
                              mainAxisAlignment: MainAxisAlignment.start,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Switch(
                                  value: _model.switchValue40!,
                                  onChanged: (newValue) async {
                                    setState(
                                        () => _model.switchValue40 = newValue!);
                                  },
                                  activeColor: Color(0xFF101518),
                                  activeTrackColor: Color(0xFF57636C),
                                  inactiveTrackColor: Color(0xFF0000FF),
                                  inactiveThumbColor: Color(0xFF57636C),
                                ),
                                Text(
                                  '\nGuglielmo Marconi',
                                  style: FlutterFlowTheme.of(context)
                                      .bodyMedium
                                      .override(
                                        fontFamily: 'Inter',
                                        color: FlutterFlowTheme.of(context)
                                            .tertiary,
                                        fontSize: 14.0,
                                        letterSpacing: 0.0,
                                        fontWeight: FontWeight.normal,
                                      ),
                                ),
                              ],
                            ),
                          ].divide(SizedBox(height: 8.0)),
                        ),
                      ].divide(SizedBox(height: 16.0)),
                    ),
                  ),
                ),
                Padding(
                  padding: EdgeInsetsDirectional.fromSTEB(0.0, 24.0, 0.0, 0.0),
                  child: Row(
                    mainAxisSize: MainAxisSize.max,
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      FFButtonWidget(
                        onPressed: () async {
                          context.pushNamed('syllabus');
                        },
                        text: 'Submit',
                        options: FFButtonOptions(
                          width: 150.0,
                          height: 50.0,
                          padding: EdgeInsetsDirectional.fromSTEB(
                              0.0, 0.0, 0.0, 0.0),
                          iconPadding: EdgeInsetsDirectional.fromSTEB(
                              0.0, 0.0, 0.0, 0.0),
                          color: FlutterFlowTheme.of(context).primary,
                          textStyle:
                              FlutterFlowTheme.of(context).titleSmall.override(
                                    fontFamily: 'Inter',
                                    color: Colors.white,
                                    fontSize: 16.0,
                                    letterSpacing: 0.0,
                                    fontWeight: FontWeight.w500,
                                  ),
                          elevation: 2.0,
                          borderRadius: BorderRadius.circular(10.0),
                        ),
                      ),
                      FFButtonWidget(
                        onPressed: () {
                          print('Button pressed ...');
                        },
                        text: 'Reset',
                        options: FFButtonOptions(
                          width: 150.0,
                          height: 50.0,
                          padding: EdgeInsetsDirectional.fromSTEB(
                              0.0, 0.0, 0.0, 0.0),
                          iconPadding: EdgeInsetsDirectional.fromSTEB(
                              0.0, 0.0, 0.0, 0.0),
                          color: FlutterFlowTheme.of(context).primary,
                          textStyle:
                              FlutterFlowTheme.of(context).titleSmall.override(
                                    fontFamily: 'Inter',
                                    color: Colors.white,
                                    fontSize: 16.0,
                                    letterSpacing: 0.0,
                                    fontWeight: FontWeight.w500,
                                  ),
                          elevation: 2.0,
                          borderRadius: BorderRadius.circular(10.0),
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
