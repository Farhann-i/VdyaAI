// Export pages
export '/pages/welcomepage/welcomepage_widget.dart' show WelcomepageWidget;
export '/basic_details/basic_details_widget.dart' show BasicDetailsWidget;
export '/assement_test/assement_test_widget.dart' show AssementTestWidget;
export '/syllabus/syllabus_widget.dart' show SyllabusWidget;
export '/listoftopics/listoftopics_widget.dart' show ListoftopicsWidget;
export '/adaptive_test/adaptive_test_widget.dart' show AdaptiveTestWidget;
